//Area del cuadrado Area=Lado*lado
#include "areas"

float cuadrado(const float& lado)
{
    float res=0;
    res=lado*lado;
    return res;
}