//Area del rectangulo Area=Base*Altura
#include "areas"

float rectangulo(const float& base,const float& altura){
    float res=0;
    res=base*altura;
    return res;
}