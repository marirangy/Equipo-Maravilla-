//Area del rombo Area=(Diagonal mayor * Diagonal menor) /2
#include "areas"

float rombo(const float& d1,const float& d2){
    float res=0;
    res=(d1*d2)/2;
    return res;
}