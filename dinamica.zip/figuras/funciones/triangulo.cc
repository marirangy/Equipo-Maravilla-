//Area del triangulo Area=(Base*Altura)/2
#include "areas"

float triangulo(const float& base,const float& altura){
    float res=0;
    res=(base*altura)/2;
    return res;
}